// == Oefening 01 - Vraag 05 ==

const songs = [
  {
    title: 'Love that music',
    duration: 265,
    genres: ['pop', 'world', 'jazz'],
  },
  { title: 'Breathing music', duration: 302, genres: [] },
  { title: 'Life is music', duration: 274, genres: ['r&b'] },
  { title: 'M for music', duration: 204, genres: ['r&b'] },
  { title: 'Music from Mars', duration: 242, genres: ['rock', 'metal'] },
];

// TODO Deel A

// Voorbeelduitvoer
console.log(shortSongs);

// TODO Deel B

// Voorbeelduitvoer
console.log(sortedSongs);
