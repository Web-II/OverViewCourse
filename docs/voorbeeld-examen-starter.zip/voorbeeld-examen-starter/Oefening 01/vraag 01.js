// == Oefening 01 - Vraag 01 ==

const names = ['Jude', 'Jude', 'Lana', 'Drew', 'Jude', 'Jude', 'Jude', 'Lana'];

// TODO Deel A
function addName(allNames, newName) {}

// Voorbeeld
addName(names, 'aNnIe');
addName(names, 'EliSA');
console.log(names);

// TODO Deel B
function isPopularName(name, allNames) {
  return allNames.filter((n) => n === name).length > 1;
}

// Voorbeeld
console.log(
  "isPopularName('Jude', names, 3) -> " + isPopularName('Jude', names, 3)
);
console.log(
  "isPopularName('Jude', names, 5) -> " + isPopularName('Jude', names, 5)
);
console.log("isPopularName('Lana', names) -> " + isPopularName('Lana', names));
console.log("isPopularName('Drew', names) -> " + isPopularName('Drew', names));
console.log(
  "isPopularName('Drew', names, 0) -> " + isPopularName('Drew', names, 0)
);

// TODO Deel C
function giveNamesWithoutRepetition(allNames) {}

// Voorbeeld
console.log(
  giveNamesWithoutRepetition([
    'Jude',
    'Jude',
    'Lana',
    'Drew',
    'Drew',
    'Jude',
    'Jude',
    'Jude',
    'Lana',
  ])
);
