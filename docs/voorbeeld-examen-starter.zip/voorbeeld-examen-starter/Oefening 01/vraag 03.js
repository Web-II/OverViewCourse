// == Oefening 01 - Vraag 03 ==

const planets = new Map([
  ['Earth', { nrOfMoons: 1, distanceFromSun: 1 }],
  ['Venus', { nrOfMoons: 0, distanceFromSun: 0.75 }],
  ['Jupiter', { nrOfMoons: 95, distanceFromSun: 5.2 }],
  ['Saturn', { nrOfMoons: 274, distanceFromSun: 9.54 }],
  ['Pluto', { nrOfMoons: 5, distanceFromSun: 39.5 }],
]);

// TODO Deel A

// TODO Deel B

// TODO Deel C

// TODO Deel D
const planetsFarAway = undefined;

// Voorbeeld
console.log(planets);
console.log(planetsFarAway);

