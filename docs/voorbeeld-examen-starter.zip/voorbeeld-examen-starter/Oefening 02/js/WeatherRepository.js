import WeatherData from "./WeatherData.js";

export default class WeatherRepository {
  #weatherData = [];

  addWeatherData(jsonData) {
    //TODO
  }

  #getWeatherDataByCity(cityName) {
    //TODO
  }

  getCurrentWeather(cityName) {
    return this.#getWeatherDataByCity(cityName).current;
  }

  getDailyForecast(cityName) {
    return this.#getWeatherDataByCity(cityName).daily;
  }

  getStatistics(cityName) {
    const dailyForecast = this.getDailyForecast(cityName);
    //TODO
  }
}
