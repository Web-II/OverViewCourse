// == Oefening 01 - Vraag 01 ==

const names = ['Jude', 'Jude', 'Lana', 'Drew', 'Jude', 'Jude', 'Jude', 'Lana'];

// TODO Deel A
function addName(allNames, newName) {
  allNames.push(
    newName.substring(0, 1).toUpperCase() + newName.substring(1).toLowerCase()
  );
}

addName(names, 'aNnIe');
addName(names, 'EliSA');
console.log(names);

// TODO Deel B
function isPopularName(name, allNames, popularityLevel = 1) {
  return allNames.filter((n) => n === name).length > popularityLevel;
}

console.log(
  "isPopularName('Jude', names, 3) -> " + isPopularName('Jude', names, 3)
);
console.log(
  "isPopularName('Jude', names, 5) -> " + isPopularName('Jude', names, 5)
);
console.log("isPopularName('Lana', names) -> " + isPopularName('Lana', names));
console.log("isPopularName('Drew', names) -> " + isPopularName('Drew', names));
console.log(
  "isPopularName('Drew', names, 0) -> " + isPopularName('Drew', names, 0)
);

// TODO Deel C
function giveNamesWithoutRepetition(allNames) {
  return allNames.reduce((pv, c) => {
    if (pv.length === 0 || pv[pv.length - 1] !== c) pv.push(c);
    return pv;
  }, []);
}

console.log(
  giveNamesWithoutRepetition([
    'Jude',
    'Jude',
    'Lana',
    'Drew',
    'Drew',
    'Jude',
    'Jude',
    'Jude',
    'Lana',
  ])
);
