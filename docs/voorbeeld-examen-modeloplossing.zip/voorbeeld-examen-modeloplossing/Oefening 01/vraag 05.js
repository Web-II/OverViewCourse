// == Oefening 01 - Vraag 05 ==

const songs = [
  {
    title: 'Love that music',
    duration: 265,
    genres: ['pop', 'world', 'jazz'],
  },
  { title: 'Breathing music', duration: 302, genres: [] },
  { title: 'Life is music', duration: 274, genres: ['r&b'] },
  { title: 'M for music', duration: 204, genres: ['r&b'] },
  { title: 'Music from Mars', duration: 242, genres: ['rock', 'metal'] },
];

// Deel A
const shortSongs = songs.filter((s) => s.duration < 250);
console.log(shortSongs);

// Deel B
const sortedSongs = songs.toSorted((s1, s2) => {
  const genreComparison = s1.genres.length - s2.genres.length;
  if (genreComparison !== 0) return genreComparison;
  if (s1.title < s2.title) return -1;
  if (s1.title > s2.title) return 1;
  return 0;
});
console.log(sortedSongs);
