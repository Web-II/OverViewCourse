import WeatherData from "./WeatherData.js";

export default class WeatherRepository {
  #weatherData = [];

  async addWeatherData(jsonData) {
    //TODO
    jsonData.forEach((city) =>
      this.#weatherData.push(
        new WeatherData(city.city, city.current, city.daily)
      )
    );
  }

  #getWeatherDataByCity(cityName) {
    return this.#weatherData.find((wd) => wd.city === cityName);
  }

  getCurrentWeather(cityName) {
    return this.#getWeatherDataByCity(cityName).current;
  }

  getDailyForecast(cityName) {
    return this.#getWeatherDataByCity(cityName).daily;
  }

  getStatistics(cityName) {
    const dailyForecast = this.getDailyForecast(cityName);
    //TODO met object reeds aangemaakt maar voor alle waarden staat 0
    return {
      minTemperature: Math.min(...dailyForecast.map((day) => day.minTemp)),
      maxTemperature: Math.max(...dailyForecast.map((day) => day.maxTemp)),
      averageHumidity:
        dailyForecast.reduce((total, day) => total + day.humidity, 0) /
        dailyForecast.length,
    };
  }
}
